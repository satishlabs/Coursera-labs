package com.satishlabs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMysqlJpaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
