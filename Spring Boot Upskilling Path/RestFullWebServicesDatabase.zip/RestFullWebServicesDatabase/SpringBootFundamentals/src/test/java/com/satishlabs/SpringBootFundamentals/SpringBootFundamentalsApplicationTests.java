package com.satishlabs.SpringBootFundamentals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFundamentalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
