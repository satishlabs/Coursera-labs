package com.satishlabs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityHelloWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityHelloWorldApplication.class, args);
	}

}
